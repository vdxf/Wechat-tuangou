<template>
  <div>
    <routerView></routerView>
  </div>
</template>

<script lang="ts" setup>
</script>

<style>
</style>