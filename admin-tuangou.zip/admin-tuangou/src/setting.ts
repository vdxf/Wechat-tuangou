export default {
  title: '新友团管理平台',
  logo: '/public/logo.png'
}