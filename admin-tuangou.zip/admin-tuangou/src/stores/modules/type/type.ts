export interface UserState {
  AccessToken: string | null;
  Id: string | null;
  menuRoutes: []
}